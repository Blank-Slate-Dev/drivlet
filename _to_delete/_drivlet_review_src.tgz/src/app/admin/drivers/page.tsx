// src/app/admin/drivers/page.tsx
"use client";

import { useEffect, useState, useCallback } from "react";
import {
  Car,
  Search,
  RefreshCw,
  Clock,
  CheckCircle,
  XCircle,
  AlertCircle,
  Eye,
  X,
  MapPin,
  Phone,
  Mail,
  Shield,
  CreditCard,
  Calendar,
  User,
  Users,
  Filter,
  Ban,
  FileText,
  Briefcase,
  Star,
  Trash2,
  AlertTriangle,
  History,
  IdCard,
  Settings2,
  ImageIcon,
  ExternalLink,
  ShieldCheck,
} from "lucide-react";

interface Driver {
  _id: string;
  firstName: string;
  lastName: string;
  phone: string;
  dateOfBirth?: string;
  address: {
    street: string;
    suburb: string;
    state: string;
    postcode: string;
  };
  license: {
    number: string;
    state: string;
    class: string;
    expiryDate: string;
    photoUrl?: string; // legacy single photo
    frontPhotoUrl?: string;
    backPhotoUrl?: string;
  };
  canDriveManual?: boolean;
  rightToWork?: {
    status?: "citizen" | "permanent_resident" | "visa_with_work_rights";
    visaSubclass?: string;
  };
  policeCheck?: {
    completed: boolean;
    certificateNumber?: string;
    issueDate?: string;
    expiryDate?: string;
    documentUrl?: string;
  };
  hasOwnVehicle: boolean;
  vehicle?: {
    make: string;
    model: string;
    year: number;
    color: string;
    registration: string;
    registrationState: string;
    registrationExpiry: string;
  };
  availability: {
    monday: { available: boolean; startTime: string; endTime: string };
    tuesday: { available: boolean; startTime: string; endTime: string };
    wednesday: { available: boolean; startTime: string; endTime: string };
    thursday: { available: boolean; startTime: string; endTime: string };
    friday: { available: boolean; startTime: string; endTime: string };
    saturday: { available: boolean; startTime: string; endTime: string };
    sunday: { available: boolean; startTime: string; endTime: string };
  };
  maxJobsPerDay: number;
  preferredAreas: string[];
  employmentType: "employee" | "contractor";
  abn?: string;
  // Optional — payment details are collected after the application is approved
  bankDetails?: {
    accountName?: string;
    bsb?: string;
    accountNumber?: string;
  };
  emergencyContact: {
    name: string;
    relationship: string;
    phone: string;
  };
  metrics?: {
    totalJobs: number;
    completedJobs: number;
    cancelledJobs: number;
    averageRating: number;
    totalRatings: number;
  };
  status: "pending" | "approved" | "rejected" | "suspended";
  submittedAt: string;
  reviewedAt?: string;
  rejectionReason?: string;
  rejectionHistory?: Array<{
    rejectedAt: string;
    rejectedBy: string;
    reason: string;
  }>;
  isActive: boolean;
  canAcceptJobs: boolean;
  isClockedIn?: boolean;
  lastClockIn?: string;
  lastClockOut?: string;
  userId?: {
    email: string;
    username: string;
    createdAt: string;
    accountStatus?: string;
  };
}

interface Stats {
  total: number;
  pending: number;
  approved: number;
  rejected: number;
  suspended: number;
  clockedIn?: number;
}

type StatusFilter = "all" | "pending" | "approved" | "rejected" | "suspended";

const LICENSE_CLASS_LABELS: Record<string, string> = {
  C: "Car (C)",
  LR: "Light Rigid (LR)",
  MR: "Medium Rigid (MR)",
  HR: "Heavy Rigid (HR)",
  HC: "Heavy Combination (HC)",
  MC: "Multi Combination (MC)",
};

const DAY_LABELS: Record<string, string> = {
  monday: "Mon",
  tuesday: "Tue",
  wednesday: "Wed",
  thursday: "Thu",
  friday: "Fri",
  saturday: "Sat",
  sunday: "Sun",
};

const RIGHT_TO_WORK_LABELS: Record<string, string> = {
  citizen: "Australian citizen",
  permanent_resident: "Permanent resident",
  visa_with_work_rights: "Visa with work rights",
};

// A police check issued more than 12 months ago is considered expired
const isPoliceCheckExpired = (issueDate?: string): boolean => {
  if (!issueDate) return false;
  const issued = new Date(issueDate);
  if (isNaN(issued.getTime())) return false;
  const cutoff = new Date();
  cutoff.setMonth(cutoff.getMonth() - 12);
  return issued < cutoff;
};

// Label a document URL as PDF or Image based on its extension
const docKindFromUrl = (url: string): "PDF" | "Image" =>
  /\.pdf($|\?)/i.test(url) ? "PDF" : "Image";

export default function AdminDriversPage() {
  const [drivers, setDrivers] = useState<Driver[]>([]);
  const [stats, setStats] = useState<Stats>({
    total: 0,
    pending: 0,
    approved: 0,
    rejected: 0,
    suspended: 0,
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<StatusFilter>("all");
  const [selectedDriver, setSelectedDriver] = useState<Driver | null>(null);
  // Gate for the Approve/Reject buttons on pending applications — admin must confirm
  // they've reviewed the application (incl. documents) before actions appear.
  const [reviewConfirmed, setReviewConfirmed] = useState(false);
  const [actionLoading, setActionLoading] = useState(false);
  const [rejectionReason, setRejectionReason] = useState("");
  const [showRejectModal, setShowRejectModal] = useState(false);
  const [driverToReject, setDriverToReject] = useState<string | null>(null);

  // Account access actions (password help + disable/enable)
  const [accountActionLoading, setAccountActionLoading] = useState(false);
  const [accountActionMessage, setAccountActionMessage] = useState("");

  const handleAccountAction = async (
    action: "send_reset" | "set_temporary" | "suspend" | "reactivate",
    extra?: Record<string, unknown>
  ) => {
    if (!selectedDriver) return;
    setAccountActionLoading(true);
    setAccountActionMessage("");
    try {
      const call = async (payload: Record<string, unknown>) => {
        const res = await fetch(`/api/admin/drivers/${selectedDriver._id}/account`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });
        return { res, data: await res.json() };
      };

      let { res, data } = await call({ action, ...extra });

      // Suspend with active jobs: server asks for confirmation first
      if (res.status === 409 && data.requiresConfirmation) {
        const proceed = window.confirm(
          `${data.error}\n\nDisable the account anyway?`
        );
        if (!proceed) {
          setAccountActionMessage("Cancelled. No changes made.");
          return;
        }
        ({ res, data } = await call({ action, ...extra, confirm: true }));
      }

      if (!res.ok) throw new Error(data.error || "Action failed");
      setAccountActionMessage(data.message || "Done");

      // Reflect the new account status in the open modal immediately
      if (action === "suspend" || action === "reactivate") {
        setSelectedDriver((prev) =>
          prev
            ? {
                ...prev,
                userId: prev.userId
                  ? { ...prev.userId, accountStatus: action === "suspend" ? "suspended" : "active" }
                  : prev.userId,
              }
            : prev
        );
        fetchDrivers();
      }
    } catch (err) {
      setAccountActionMessage(`Error: ${err instanceof Error ? err.message : "Action failed"}`);
    } finally {
      setAccountActionLoading(false);
    }
  };
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [driverToDelete, setDriverToDelete] = useState<string | null>(null);
  const [deleteConfirmText, setDeleteConfirmText] = useState("");

  const fetchDrivers = useCallback(async () => {
    try {
      setLoading(true);
      const params = new URLSearchParams();
      if (statusFilter !== "all") params.set("status", statusFilter);

      const response = await fetch(`/api/admin/drivers?${params.toString()}`);
      if (!response.ok) throw new Error("Failed to fetch drivers");
      const data = await response.json();
      setDrivers(data.drivers);
      setStats(data.stats);
      setError("");
    } catch {
      setError("Failed to load driver applications");
    } finally {
      setLoading(false);
    }
  }, [statusFilter]);

  useEffect(() => {
    fetchDrivers();
  }, [fetchDrivers]);

  // Reset the review-confirmation gate whenever the modal opens/closes or the
  // selected driver changes, so each application must be confirmed independently.
  useEffect(() => {
    setReviewConfirmed(false);
  }, [selectedDriver?._id]);

  const handleAction = async (driverId: string, action: string, reason?: string) => {
    try {
      setActionLoading(true);
      const response = await fetch("/api/admin/drivers", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ driverId, action, rejectionReason: reason }),
      });

      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.error || "Failed to update driver");
      }

      // Refresh the list
      await fetchDrivers();
      setSelectedDriver(null);
      setShowRejectModal(false);
      setRejectionReason("");
      setDriverToReject(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to update driver");
    } finally {
      setActionLoading(false);
    }
  };

  const openRejectModal = (driverId: string) => {
    setDriverToReject(driverId);
    setShowRejectModal(true);
  };

  const handleDelete = async (driverId: string) => {
    if (deleteConfirmText !== "DELETE") {
      setError("Please type DELETE to confirm");
      return;
    }

    try {
      setActionLoading(true);
      const response = await fetch(
        `/api/admin/drivers?driverId=${driverId}&confirm=true`,
        { method: "DELETE" }
      );

      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.error || "Failed to delete driver");
      }

      // Refresh the list
      await fetchDrivers();
      setShowDeleteModal(false);
      setDriverToDelete(null);
      setDeleteConfirmText("");
      setSelectedDriver(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to delete driver");
    } finally {
      setActionLoading(false);
    }
  };

  const openDeleteModal = (driverId: string) => {
    setDriverToDelete(driverId);
    setDeleteConfirmText("");
    setShowDeleteModal(true);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("en-AU", {
      day: "numeric",
      month: "short",
      year: "numeric",
    });
  };

  const formatDateTime = (dateString: string) => {
    return new Date(dateString).toLocaleString("en-AU", {
      day: "numeric",
      month: "short",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "pending":
        return "bg-amber-100 text-amber-700";
      case "approved":
        return "bg-green-100 text-green-700";
      case "rejected":
        return "bg-red-100 text-red-700";
      case "suspended":
        return "bg-slate-100 text-slate-700";
      default:
        return "bg-slate-100 text-slate-700";
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "pending":
        return <Clock className="h-4 w-4" />;
      case "approved":
        return <CheckCircle className="h-4 w-4" />;
      case "rejected":
        return <XCircle className="h-4 w-4" />;
      case "suspended":
        return <Ban className="h-4 w-4" />;
      default:
        return null;
    }
  };

  const getAvailableDays = (availability: Driver["availability"]) => {
    const days = Object.entries(availability)
      .filter(([, value]) => value.available)
      .map(([key]) => DAY_LABELS[key]);
    return days.length > 0 ? days.join(", ") : "None";
  };

  // Filter drivers based on search
  const filteredDrivers = drivers.filter((driver) => {
    if (!search) return true;
    const searchLower = search.toLowerCase();
    const fullName = `${driver.firstName} ${driver.lastName}`.toLowerCase();
    const email = driver.userId?.email?.toLowerCase() || "";
    return (
      fullName.includes(searchLower) ||
      email.includes(searchLower) ||
      driver.phone.includes(search) ||
      driver.license.number.toLowerCase().includes(searchLower) ||
      driver.address.suburb.toLowerCase().includes(searchLower)
    );
  });

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="text-3xl font-bold text-slate-900">Driver Applications</h1>
            <p className="mt-1 text-slate-600">
              Review and manage driver partner submissions
            </p>
          </div>
          <button
            onClick={fetchDrivers}
            className="group inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-5 py-2.5 text-sm font-medium text-slate-700 shadow-sm transition hover:bg-slate-50 hover:border-slate-300"
          >
            <RefreshCw className={`h-4 w-4 transition-transform group-hover:rotate-180 ${loading ? "animate-spin" : ""}`} />
            Refresh
          </button>
        </div>

        {/* Stats Cards */}
        <div className="mb-6 grid grid-cols-2 gap-4 lg:grid-cols-5">
          <div className="rounded-2xl border border-slate-200 bg-gradient-to-br from-emerald-500 to-teal-600 p-5 shadow-sm">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-white/20">
                <Car className="h-5 w-5 text-white" />
              </div>
              <div>
                <p className="text-xl font-bold text-white">{stats.total}</p>
                <p className="text-xs text-emerald-100">Total</p>
              </div>
            </div>
          </div>

          <button
            onClick={() => setStatusFilter("pending")}
            className={`rounded-2xl border p-5 shadow-sm transition hover:shadow-md text-left ${
              statusFilter === "pending"
                ? "border-amber-300 bg-amber-50"
                : "border-slate-200 bg-white"
            }`}
          >
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-amber-100">
                <Clock className="h-5 w-5 text-amber-600" />
              </div>
              <div>
                <p className="text-xl font-bold text-slate-900">{stats.pending}</p>
                <p className="text-xs text-slate-500">Pending</p>
              </div>
            </div>
          </button>

          <button
            onClick={() => setStatusFilter("approved")}
            className={`rounded-2xl border p-5 shadow-sm transition hover:shadow-md text-left ${
              statusFilter === "approved"
                ? "border-green-300 bg-green-50"
                : "border-slate-200 bg-white"
            }`}
          >
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-green-100">
                <CheckCircle className="h-5 w-5 text-green-600" />
              </div>
              <div>
                <p className="text-xl font-bold text-slate-900">{stats.approved}</p>
                <p className="text-xs text-slate-500">Approved</p>
              </div>
            </div>
          </button>

          <button
            onClick={() => setStatusFilter("rejected")}
            className={`rounded-2xl border p-5 shadow-sm transition hover:shadow-md text-left ${
              statusFilter === "rejected"
                ? "border-red-300 bg-red-50"
                : "border-slate-200 bg-white"
            }`}
          >
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-red-100">
                <XCircle className="h-5 w-5 text-red-600" />
              </div>
              <div>
                <p className="text-xl font-bold text-slate-900">{stats.rejected}</p>
                <p className="text-xs text-slate-500">Rejected</p>
              </div>
            </div>
          </button>

          <button
            onClick={() => setStatusFilter("suspended")}
            className={`rounded-2xl border p-5 shadow-sm transition hover:shadow-md text-left ${
              statusFilter === "suspended"
                ? "border-slate-400 bg-slate-100"
                : "border-slate-200 bg-white"
            }`}
          >
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-slate-200">
                <Ban className="h-5 w-5 text-slate-600" />
              </div>
              <div>
                <p className="text-xl font-bold text-slate-900">{stats.suspended}</p>
                <p className="text-xs text-slate-500">Suspended</p>
              </div>
            </div>
          </button>
        </div>

        {/* Search and Filter Bar */}
        <div className="mb-6 flex flex-col gap-4 rounded-2xl border border-slate-200 bg-white p-4 shadow-sm sm:flex-row sm:items-center">
          <div className="relative flex-1">
            <Search className="absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Search by name, email, phone, license, or suburb..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full rounded-xl border border-slate-200 bg-white py-3 pl-11 pr-4 text-sm text-slate-900 placeholder:text-slate-400 focus:border-emerald-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
            />
          </div>
          <div className="flex gap-2">
            <div className="relative">
              <Filter className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value as StatusFilter)}
                className="appearance-none rounded-xl border border-slate-200 bg-white py-3 pl-10 pr-8 text-sm text-slate-900 focus:border-emerald-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
              >
                <option value="all">All Status</option>
                <option value="pending">Pending</option>
                <option value="approved">Approved</option>
                <option value="rejected">Rejected</option>
                <option value="suspended">Suspended</option>
              </select>
            </div>
          </div>
        </div>

        {/* Error State */}
        {error && (
          <div className="mb-6 rounded-2xl border border-red-200 bg-red-50 p-6 text-center">
            <AlertCircle className="mx-auto h-8 w-8 text-red-500" />
            <p className="mt-2 text-sm font-medium text-red-700">{error}</p>
            <button
              onClick={fetchDrivers}
              className="mt-3 text-sm font-medium text-red-600 hover:text-red-700"
            >
              Try again
            </button>
          </div>
        )}

        {/* Drivers Table */}
        <div className="rounded-2xl border border-slate-200 bg-white shadow-sm">
          {loading ? (
            <div className="p-12 text-center">
              <RefreshCw className="mx-auto h-8 w-8 animate-spin text-emerald-500" />
              <p className="mt-3 text-sm text-slate-500">Loading applications...</p>
            </div>
          ) : filteredDrivers.length === 0 ? (
            <div className="p-12 text-center">
              <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-slate-100">
                <Car className="h-8 w-8 text-slate-400" />
              </div>
              <p className="mt-4 text-sm font-medium text-slate-600">
                {search ? "No drivers found matching your search" : "No driver applications found"}
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead className="border-b border-slate-100 text-xs font-medium uppercase tracking-wide text-slate-500">
                  <tr>
                    <th className="px-6 py-4">Driver</th>
                    <th className="px-6 py-4">Location</th>
                    <th className="px-6 py-4">License</th>
                    <th className="px-6 py-4">Type</th>
                    <th className="px-6 py-4">Status</th>
                    <th className="px-6 py-4">Clock</th>
                    <th className="px-6 py-4">Submitted</th>
                    <th className="px-6 py-4">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredDrivers.map((driver) => (
                    <tr key={driver._id} className="transition hover:bg-slate-50">
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-3">
                          <div className="flex h-10 w-10 items-center justify-center rounded-full bg-emerald-100 text-sm font-semibold text-emerald-700">
                            {driver.firstName.charAt(0)}{driver.lastName.charAt(0)}
                          </div>
                          <div>
                            <p className="font-medium text-slate-900">
                              {driver.firstName} {driver.lastName}
                            </p>
                            <p className="text-xs text-slate-500">
                              {driver.userId?.email || driver.phone}
                            </p>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <p className="text-sm text-slate-900">
                          {driver.address.suburb}, {driver.address.state}
                        </p>
                        <p className="text-xs text-slate-500">
                          {driver.preferredAreas.slice(0, 2).join(", ")}
                          {driver.preferredAreas.length > 2 && ` +${driver.preferredAreas.length - 2}`}
                        </p>
                      </td>
                      <td className="px-6 py-4">
                        <p className="text-sm text-slate-900">{driver.license.number}</p>
                        <p className="text-xs text-slate-500">
                          {LICENSE_CLASS_LABELS[driver.license.class] || driver.license.class} • {driver.license.state}
                        </p>
                      </td>
                      <td className="px-6 py-4">
                        <span className={`inline-flex items-center rounded-full px-2.5 py-1 text-xs font-medium ${
                          driver.employmentType === "contractor"
                            ? "bg-purple-100 text-purple-700"
                            : "bg-blue-100 text-blue-700"
                        }`}>
                          {driver.employmentType === "contractor" ? "Contractor" : "Employee"}
                        </span>
                        {driver.hasOwnVehicle && (
                          <span className="ml-1 inline-flex items-center rounded-full bg-slate-100 px-2 py-0.5 text-xs text-slate-600">
                            <Car className="mr-1 h-3 w-3" />
                            Own car
                          </span>
                        )}
                      </td>
                      <td className="px-6 py-4">
                        <span className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-medium ${getStatusColor(driver.status)}`}>
                          {getStatusIcon(driver.status)}
                          {driver.status}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        {driver.status === "approved" ? (
                          <span className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-medium ${
                            driver.isClockedIn
                              ? "bg-emerald-100 text-emerald-700"
                              : "bg-slate-100 text-slate-600"
                          }`}>
                            <span className={`w-2 h-2 rounded-full ${driver.isClockedIn ? "bg-emerald-500 animate-pulse" : "bg-slate-400"}`} />
                            {driver.isClockedIn ? "Active" : "Off"}
                          </span>
                        ) : (
                          <span className="text-xs text-slate-400">—</span>
                        )}
                      </td>
                      <td className="px-6 py-4">
                        <p className="text-sm text-slate-600">{formatDate(driver.submittedAt)}</p>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => setSelectedDriver(driver)}
                            className="flex items-center gap-1.5 rounded-lg border border-slate-200 px-3 py-2 text-xs font-medium text-slate-700 transition hover:bg-emerald-50 hover:border-emerald-200 hover:text-emerald-700"
                          >
                            <Eye className="h-3.5 w-3.5" />
                            View
                          </button>
                          {driver.status === "pending" && (
                            <>
                              <button
                                onClick={() => handleAction(driver._id, "approve")}
                                disabled={actionLoading}
                                className="flex items-center gap-1.5 rounded-lg bg-green-600 px-3 py-2 text-xs font-medium text-white transition hover:bg-green-700 disabled:opacity-50"
                              >
                                <CheckCircle className="h-3.5 w-3.5" />
                                Approve
                              </button>
                              <button
                                onClick={() => openRejectModal(driver._id)}
                                disabled={actionLoading}
                                className="flex items-center gap-1.5 rounded-lg bg-red-600 px-3 py-2 text-xs font-medium text-white transition hover:bg-red-700 disabled:opacity-50"
                              >
                                <XCircle className="h-3.5 w-3.5" />
                                Reject
                              </button>
                            </>
                          )}
                          {driver.status === "rejected" && (
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                openDeleteModal(driver._id);
                              }}
                              className="flex items-center gap-1 rounded-lg border border-red-200 px-3 py-1.5 text-xs font-medium text-red-600 transition hover:bg-red-50"
                            >
                              <Trash2 className="h-3 w-3" />
                              Delete
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {/* Results count */}
          {!loading && filteredDrivers.length > 0 && (
            <div className="border-t border-slate-100 px-6 py-4">
              <p className="text-sm text-slate-500">
                Showing {filteredDrivers.length} of {drivers.length} applications
                {search && ` matching "${search}"`}
                {statusFilter !== "all" && ` (${statusFilter})`}
              </p>
            </div>
          )}
        </div>

        {/* Driver Details Modal */}
        {selectedDriver && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
            <div className="w-full max-w-2xl max-h-[90vh] overflow-y-auto rounded-3xl bg-white shadow-2xl">
              <div className="sticky top-0 flex items-center justify-between border-b border-slate-200 bg-white px-6 py-4 rounded-t-3xl">
                <div className="flex items-center gap-3">
                  <h2 className="text-lg font-semibold text-slate-900">
                    {selectedDriver.firstName} {selectedDriver.lastName}
                  </h2>
                  <span className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-medium ${getStatusColor(selectedDriver.status)}`}>
                    {getStatusIcon(selectedDriver.status)}
                    {selectedDriver.status}
                  </span>
                </div>
                <button
                  onClick={() => setSelectedDriver(null)}
                  className="rounded-full p-2 text-slate-400 transition hover:bg-slate-100 hover:text-slate-600"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>

              <div className="space-y-6 p-6">
                {/* Personal Info */}
                <div className="rounded-xl border border-slate-200 p-4">
                  <div className="flex items-center gap-2 text-sm font-semibold text-slate-800 mb-3">
                    <User className="h-4 w-4 text-emerald-600" />
                    Personal Information
                  </div>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <p className="text-slate-500">Full Name</p>
                      <p className="font-medium text-slate-900">{selectedDriver.firstName} {selectedDriver.lastName}</p>
                    </div>
                    <div>
                      <p className="text-slate-500">Phone</p>
                      <div className="flex items-center gap-1.5">
                        <Phone className="h-4 w-4 text-slate-400" />
                        <p className="font-medium text-slate-900">{selectedDriver.phone}</p>
                      </div>
                    </div>
                    <div>
                      <p className="text-slate-500">Email</p>
                      <div className="flex items-center gap-1.5">
                        <Mail className="h-4 w-4 text-slate-400" />
                        <p className="font-medium text-slate-900">
                          {selectedDriver.userId?.email || "—"}
                        </p>
                      </div>
                    </div>
                    <div>
                      <p className="text-slate-500">Employment Type</p>
                      <span className={`inline-flex items-center rounded-full px-2.5 py-1 text-xs font-medium ${
                        selectedDriver.employmentType === "contractor"
                          ? "bg-purple-100 text-purple-700"
                          : "bg-blue-100 text-blue-700"
                      }`}>
                        <Briefcase className="mr-1 h-3 w-3" />
                        {selectedDriver.employmentType === "contractor" ? "Contractor" : "Employee"}
                      </span>
                    </div>
                    <div>
                      <p className="text-slate-500">Date of Birth</p>
                      <p className="font-medium text-slate-900">
                        {selectedDriver.dateOfBirth ? formatDate(selectedDriver.dateOfBirth) : "—"}
                      </p>
                    </div>
                    <div>
                      <p className="text-slate-500">Transmission</p>
                      {selectedDriver.canDriveManual ? (
                        <span className="inline-flex items-center rounded-full bg-teal-100 px-2.5 py-1 text-xs font-medium text-teal-700">
                          <Settings2 className="mr-1 h-3 w-3" />
                          Manual capable
                        </span>
                      ) : (
                        <span className="inline-flex items-center rounded-full bg-slate-100 px-2.5 py-1 text-xs font-medium text-slate-600">
                          <Settings2 className="mr-1 h-3 w-3" />
                          Auto only
                        </span>
                      )}
                    </div>
                    <div>
                      <p className="text-slate-500">Right to Work</p>
                      <p className="font-medium text-slate-900">
                        {selectedDriver.rightToWork?.status
                          ? RIGHT_TO_WORK_LABELS[selectedDriver.rightToWork.status] || selectedDriver.rightToWork.status
                          : "—"}
                        {selectedDriver.rightToWork?.status === "visa_with_work_rights" && selectedDriver.rightToWork?.visaSubclass && (
                          <span className="text-slate-500"> (subclass {selectedDriver.rightToWork.visaSubclass})</span>
                        )}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Address */}
                <div className="rounded-xl border border-slate-200 p-4">
                  <div className="flex items-center gap-2 text-sm font-semibold text-slate-800 mb-3">
                    <MapPin className="h-4 w-4 text-emerald-600" />
                    Address & Preferred Areas
                  </div>
                  <div className="text-sm">
                    <p className="font-medium text-slate-900">
                      {selectedDriver.address.street}
                    </p>
                    <p className="text-slate-600">
                      {selectedDriver.address.suburb}, {selectedDriver.address.state} {selectedDriver.address.postcode}
                    </p>
                    <div className="mt-3">
                      <p className="text-slate-500 mb-2">Preferred Areas</p>
                      <div className="flex flex-wrap gap-2">
                        {selectedDriver.preferredAreas.map((area) => (
                          <span key={area} className="rounded-full bg-emerald-100 px-3 py-1 text-xs font-medium text-emerald-700">
                            {area}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

                {/* License Info */}
                <div className="rounded-xl border border-slate-200 p-4">
                  <div className="flex items-center gap-2 text-sm font-semibold text-slate-800 mb-3">
                    <FileText className="h-4 w-4 text-emerald-600" />
                    License Information
                  </div>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <p className="text-slate-500">License Number</p>
                      <p className="font-medium text-slate-900">{selectedDriver.license.number}</p>
                    </div>
                    <div>
                      <p className="text-slate-500">State</p>
                      <p className="font-medium text-slate-900">{selectedDriver.license.state}</p>
                    </div>
                    <div>
                      <p className="text-slate-500">Class</p>
                      <p className="font-medium text-slate-900">
                        {LICENSE_CLASS_LABELS[selectedDriver.license.class] || selectedDriver.license.class}
                      </p>
                    </div>
                    <div>
                      <p className="text-slate-500">Expiry Date</p>
                      <p className="font-medium text-slate-900">{formatDate(selectedDriver.license.expiryDate)}</p>
                    </div>
                  </div>
                  {selectedDriver.policeCheck && (
                    <div className="mt-4 pt-4 border-t border-slate-100">
                      <div className="flex items-center gap-2">
                        <Shield className={`h-4 w-4 ${selectedDriver.policeCheck.completed ? "text-green-600" : "text-amber-600"}`} />
                        <span className={`text-sm font-medium ${selectedDriver.policeCheck.completed ? "text-green-700" : "text-amber-700"}`}>
                          Police Check: {selectedDriver.policeCheck.completed ? "Completed" : "Pending"}
                        </span>
                      </div>
                      {selectedDriver.policeCheck.certificateNumber && (
                        <p className="text-xs text-slate-500 mt-1">
                          Certificate: {selectedDriver.policeCheck.certificateNumber}
                        </p>
                      )}
                    </div>
                  )}
                </div>

                {/* Account access — password help + temporary disable */}
                <div className="rounded-xl border border-slate-200 p-4">
                  <div className="mb-3 flex items-center justify-between">
                    <div className="flex items-center gap-2 text-sm font-semibold text-slate-800">
                      <Shield className="h-4 w-4 text-emerald-600" />
                      Account access
                    </div>
                    {selectedDriver.userId?.accountStatus === "suspended" ? (
                      <span className="rounded-full bg-red-50 px-2.5 py-0.5 text-xs font-semibold text-red-700">
                        Disabled
                      </span>
                    ) : (
                      <span className="rounded-full bg-emerald-50 px-2.5 py-0.5 text-xs font-medium text-emerald-700">
                        Active
                      </span>
                    )}
                  </div>

                  {accountActionMessage && (
                    <p className={`mb-3 rounded-lg p-2.5 text-xs ${accountActionMessage.startsWith("Error") ? "bg-red-50 text-red-700" : "bg-emerald-50 text-emerald-700"}`}>
                      {accountActionMessage}
                    </p>
                  )}

                  <div className="flex flex-wrap gap-2">
                    <button
                      onClick={() => handleAccountAction("send_reset")}
                      disabled={accountActionLoading}
                      className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 px-3 py-1.5 text-xs font-medium text-slate-700 transition hover:bg-slate-50 disabled:opacity-50"
                    >
                      Send password reset email
                    </button>
                    <button
                      onClick={() => {
                        const temp = window.prompt(
                          "Set a temporary password for this driver (min 8 characters). Read it out to them and ask them to change it in Settings."
                        );
                        if (temp) handleAccountAction("set_temporary", { tempPassword: temp });
                      }}
                      disabled={accountActionLoading}
                      className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 px-3 py-1.5 text-xs font-medium text-slate-700 transition hover:bg-slate-50 disabled:opacity-50"
                    >
                      Set temporary password
                    </button>
                    {selectedDriver.userId?.accountStatus === "suspended" ? (
                      <button
                        onClick={() => {
                          if (window.confirm("Re-enable this driver's account? They'll be able to log in again.")) {
                            handleAccountAction("reactivate");
                          }
                        }}
                        disabled={accountActionLoading}
                        className="inline-flex items-center gap-1.5 rounded-lg border border-emerald-200 px-3 py-1.5 text-xs font-medium text-emerald-700 transition hover:bg-emerald-50 disabled:opacity-50"
                      >
                        Re-enable account
                      </button>
                    ) : (
                      <button
                        onClick={() => {
                          const reason = window.prompt(
                            "Temporarily disable this driver's account (e.g. resignation). They won't be able to log in until re-enabled. Reason (optional):"
                          );
                          if (reason !== null) {
                            handleAccountAction("suspend", { reason: reason || undefined });
                          }
                        }}
                        disabled={accountActionLoading}
                        className="inline-flex items-center gap-1.5 rounded-lg border border-red-200 px-3 py-1.5 text-xs font-medium text-red-700 transition hover:bg-red-50 disabled:opacity-50"
                      >
                        Disable account
                      </button>
                    )}
                  </div>
                  <p className="mt-2 text-[11px] text-slate-400">
                    Disabling blocks login and driver features immediately. If the
                    driver has active jobs you&apos;ll be warned first; reassign
                    them via Dispatch.
                  </p>
                </div>

                {/* Documents — shown for EVERY status so they remain accessible permanently, including after approval */}
                <div className="rounded-xl border border-slate-200 p-4">
                  <div className="flex items-center gap-2 text-sm font-semibold text-slate-800 mb-3">
                    <IdCard className="h-4 w-4 text-emerald-600" />
                    Documents
                  </div>

                  {/* Licence photos */}
                  {selectedDriver.license.frontPhotoUrl || selectedDriver.license.backPhotoUrl ? (
                    <div className="grid grid-cols-2 gap-3">
                      <LicenceThumb label="Licence front" url={selectedDriver.license.frontPhotoUrl} />
                      <LicenceThumb label="Licence back" url={selectedDriver.license.backPhotoUrl} />
                    </div>
                  ) : selectedDriver.license.photoUrl ? (
                    <div className="grid grid-cols-2 gap-3">
                      <LicenceThumb label="Licence photo (legacy)" url={selectedDriver.license.photoUrl} />
                    </div>
                  ) : (
                    <p className="rounded-lg bg-slate-50 border border-dashed border-slate-200 px-3 py-4 text-center text-xs text-slate-400">
                      Not provided (registered before document upload was required)
                    </p>
                  )}

                  {/* Police check document */}
                  <div className="mt-4 pt-4 border-t border-slate-100">
                    {selectedDriver.policeCheck?.documentUrl || selectedDriver.policeCheck?.certificateNumber ? (
                      <div className="rounded-lg border border-slate-200 p-3">
                        <div className="flex items-center justify-between gap-3">
                          <div className="flex items-center gap-2 text-sm font-medium text-slate-800">
                            <Shield className="h-4 w-4 text-emerald-600" />
                            Police Check
                          </div>
                          {isPoliceCheckExpired(selectedDriver.policeCheck?.issueDate) && (
                            <span className="inline-flex items-center gap-1 rounded-full bg-amber-100 px-2.5 py-1 text-xs font-medium text-amber-700">
                              <AlertTriangle className="h-3 w-3" />
                              Expired, request a new check
                            </span>
                          )}
                        </div>
                        <div className="mt-2 grid grid-cols-3 gap-3 text-xs">
                          <div>
                            <p className="text-slate-500">Certificate</p>
                            <p className="font-medium text-slate-900 break-words">{selectedDriver.policeCheck?.certificateNumber || "—"}</p>
                          </div>
                          <div>
                            <p className="text-slate-500">Issued</p>
                            <p className="font-medium text-slate-900">{selectedDriver.policeCheck?.issueDate ? formatDate(selectedDriver.policeCheck.issueDate) : "—"}</p>
                          </div>
                          <div>
                            <p className="text-slate-500">Expires</p>
                            <p className="font-medium text-slate-900">{selectedDriver.policeCheck?.expiryDate ? formatDate(selectedDriver.policeCheck.expiryDate) : "—"}</p>
                          </div>
                        </div>
                        {selectedDriver.policeCheck?.documentUrl && (
                          <a
                            href={selectedDriver.policeCheck.documentUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="mt-3 inline-flex items-center gap-1.5 rounded-lg border border-slate-200 px-3 py-2 text-xs font-medium text-slate-700 transition hover:bg-emerald-50 hover:border-emerald-200 hover:text-emerald-700"
                          >
                            <FileText className="h-3.5 w-3.5" />
                            View document ({docKindFromUrl(selectedDriver.policeCheck.documentUrl)})
                            <ExternalLink className="h-3 w-3" />
                          </a>
                        )}
                      </div>
                    ) : (
                      <p className="rounded-lg bg-slate-50 border border-dashed border-slate-200 px-3 py-4 text-center text-xs text-slate-400">
                        No police check on file
                      </p>
                    )}
                  </div>
                </div>

                {/* Vehicle Info (if applicable) */}
                {selectedDriver.hasOwnVehicle && selectedDriver.vehicle && (
                  <div className="rounded-xl border border-slate-200 p-4">
                    <div className="flex items-center gap-2 text-sm font-semibold text-slate-800 mb-3">
                      <Car className="h-4 w-4 text-emerald-600" />
                      Vehicle Information
                    </div>
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <p className="text-slate-500">Vehicle</p>
                        <p className="font-medium text-slate-900">
                          {selectedDriver.vehicle.year} {selectedDriver.vehicle.make} {selectedDriver.vehicle.model}
                        </p>
                        <p className="text-slate-600">{selectedDriver.vehicle.color}</p>
                      </div>
                      <div>
                        <p className="text-slate-500">Registration</p>
                        <p className="font-medium text-slate-900">
                          {selectedDriver.vehicle.registration} ({selectedDriver.vehicle.registrationState})
                        </p>
                        <p className="text-xs text-slate-500">
                          Expires: {formatDate(selectedDriver.vehicle.registrationExpiry)}
                        </p>
                      </div>
                    </div>
                  </div>
                )}

                {/* Availability */}
                <div className="rounded-xl border border-slate-200 p-4">
                  <div className="flex items-center gap-2 text-sm font-semibold text-slate-800 mb-3">
                    <Calendar className="h-4 w-4 text-emerald-600" />
                    Availability
                  </div>
                  <div className="grid grid-cols-7 gap-2 text-center">
                    {Object.entries(selectedDriver.availability).map(([day, hours]) => (
                      <div
                        key={day}
                        className={`rounded-lg p-2 ${
                          hours.available
                            ? "bg-emerald-50 border border-emerald-200"
                            : "bg-slate-50 border border-slate-200"
                        }`}
                      >
                        <p className={`text-xs font-medium ${hours.available ? "text-emerald-700" : "text-slate-400"}`}>
                          {DAY_LABELS[day]}
                        </p>
                        {hours.available && (
                          <p className="text-xs text-emerald-600 mt-1">
                            {hours.startTime}-{hours.endTime}
                          </p>
                        )}
                      </div>
                    ))}
                  </div>
                  <p className="mt-3 text-sm text-slate-600">
                    Max jobs per day: <span className="font-medium text-slate-900">{selectedDriver.maxJobsPerDay}</span>
                  </p>
                </div>

                {/* Bank Details */}
                <div className="rounded-xl border border-slate-200 p-4">
                  <div className="flex items-center gap-2 text-sm font-semibold text-slate-800 mb-3">
                    <CreditCard className="h-4 w-4 text-emerald-600" />
                    Bank Details
                  </div>
                  {selectedDriver.bankDetails?.accountName || selectedDriver.bankDetails?.bsb || selectedDriver.bankDetails?.accountNumber ? (
                    <div className="grid grid-cols-3 gap-4 text-sm">
                      <div>
                        <p className="text-slate-500">Account Name</p>
                        <p className="font-medium text-slate-900">{selectedDriver.bankDetails?.accountName || "—"}</p>
                      </div>
                      <div>
                        <p className="text-slate-500">BSB</p>
                        <p className="font-medium text-slate-900">{selectedDriver.bankDetails?.bsb || "—"}</p>
                      </div>
                      <div>
                        <p className="text-slate-500">Account Number</p>
                        <p className="font-medium text-slate-900">
                          {selectedDriver.bankDetails?.accountNumber ? `****${selectedDriver.bankDetails.accountNumber.slice(-4)}` : "—"}
                        </p>
                      </div>
                    </div>
                  ) : (
                    <p className="text-sm text-slate-500">Not provided. Payment details are collected after approval.</p>
                  )}
                  {selectedDriver.abn && (
                    <div className="mt-3 pt-3 border-t border-slate-100">
                      <p className="text-slate-500 text-sm">ABN</p>
                      <p className="font-medium text-slate-900 text-sm">{selectedDriver.abn}</p>
                    </div>
                  )}
                </div>

                {/* Emergency Contact */}
                <div className="rounded-xl border border-slate-200 p-4">
                  <div className="flex items-center gap-2 text-sm font-semibold text-slate-800 mb-3">
                    <Users className="h-4 w-4 text-emerald-600" />
                    Emergency Contact
                  </div>
                  <div className="grid grid-cols-3 gap-4 text-sm">
                    <div>
                      <p className="text-slate-500">Name</p>
                      <p className="font-medium text-slate-900">{selectedDriver.emergencyContact.name}</p>
                    </div>
                    <div>
                      <p className="text-slate-500">Relationship</p>
                      <p className="font-medium text-slate-900">{selectedDriver.emergencyContact.relationship}</p>
                    </div>
                    <div>
                      <p className="text-slate-500">Phone</p>
                      <p className="font-medium text-slate-900">{selectedDriver.emergencyContact.phone}</p>
                    </div>
                  </div>
                </div>

                {/* Clock Status (for approved drivers) */}
                {selectedDriver.status === "approved" && (
                  <div className="rounded-xl border border-slate-200 p-4">
                    <div className="flex items-center gap-2 text-sm font-semibold text-slate-800 mb-3">
                      <Clock className="h-4 w-4 text-emerald-600" />
                      Clock Status
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className={`flex h-10 w-10 items-center justify-center rounded-full ${
                          selectedDriver.isClockedIn ? "bg-emerald-100" : "bg-slate-100"
                        }`}>
                          <Clock className={`h-5 w-5 ${selectedDriver.isClockedIn ? "text-emerald-600" : "text-slate-500"}`} />
                        </div>
                        <div>
                          <p className={`font-medium ${selectedDriver.isClockedIn ? "text-emerald-700" : "text-slate-700"}`}>
                            {selectedDriver.isClockedIn ? "Currently Clocked In" : "Not Clocked In"}
                          </p>
                          {selectedDriver.isClockedIn && selectedDriver.lastClockIn && (
                            <p className="text-xs text-slate-500">
                              Since {formatDateTime(selectedDriver.lastClockIn)}
                            </p>
                          )}
                          {!selectedDriver.isClockedIn && selectedDriver.lastClockOut && (
                            <p className="text-xs text-slate-500">
                              Last clocked out: {formatDateTime(selectedDriver.lastClockOut)}
                            </p>
                          )}
                        </div>
                      </div>
                      {selectedDriver.isClockedIn && (
                        <span className="inline-flex items-center gap-1.5 rounded-full bg-emerald-100 px-3 py-1.5 text-xs font-medium text-emerald-700">
                          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                          Active
                        </span>
                      )}
                    </div>
                  </div>
                )}

                {/* Metrics (for approved drivers) */}
                {selectedDriver.status === "approved" && selectedDriver.metrics && (
                  <div className="rounded-xl border border-slate-200 p-4">
                    <div className="flex items-center gap-2 text-sm font-semibold text-slate-800 mb-3">
                      <Star className="h-4 w-4 text-emerald-600" />
                      Performance Metrics
                    </div>
                    <div className="grid grid-cols-4 gap-4 text-center">
                      <div>
                        <p className="text-2xl font-bold text-slate-900">{selectedDriver.metrics.totalJobs}</p>
                        <p className="text-xs text-slate-500">Total Jobs</p>
                      </div>
                      <div>
                        <p className="text-2xl font-bold text-green-600">{selectedDriver.metrics.completedJobs}</p>
                        <p className="text-xs text-slate-500">Completed</p>
                      </div>
                      <div>
                        <p className="text-2xl font-bold text-red-600">{selectedDriver.metrics.cancelledJobs}</p>
                        <p className="text-xs text-slate-500">Cancelled</p>
                      </div>
                      <div>
                        <p className="text-2xl font-bold text-amber-600">
                          {selectedDriver.metrics.averageRating.toFixed(1)}
                        </p>
                        <p className="text-xs text-slate-500">
                          Rating ({selectedDriver.metrics.totalRatings})
                        </p>
                      </div>
                    </div>
                  </div>
                )}

                {/* Timeline */}
                <div className="rounded-xl border border-slate-200 p-4">
                  <div className="flex items-center gap-2 text-sm font-semibold text-slate-800 mb-3">
                    <Clock className="h-4 w-4 text-emerald-600" />
                    Timeline
                  </div>
                  <div className="text-sm space-y-2">
                    <p className="text-slate-600">
                      Submitted: <span className="font-medium text-slate-900">{formatDateTime(selectedDriver.submittedAt)}</span>
                    </p>
                    {selectedDriver.reviewedAt && (
                      <p className="text-slate-600">
                        Reviewed: <span className="font-medium text-slate-900">{formatDateTime(selectedDriver.reviewedAt)}</span>
                      </p>
                    )}
                    {selectedDriver.rejectionReason && (
                      <div className="mt-2 p-3 bg-red-50 border border-red-200 rounded-lg">
                        <p className="text-red-700 font-medium">Rejection Reason:</p>
                        <p className="text-red-600">{selectedDriver.rejectionReason}</p>
                      </div>
                    )}
                  </div>
                </div>

                {/* Action Buttons — gated behind a review confirmation for pending apps */}
                {selectedDriver.status === "pending" && (
                  !reviewConfirmed ? (
                    <div className="pt-4 border-t border-slate-200">
                      <label className="flex items-start gap-3 rounded-xl border border-slate-200 bg-slate-50 p-4 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={reviewConfirmed}
                          onChange={(e) => setReviewConfirmed(e.target.checked)}
                          className="mt-0.5 h-5 w-5 rounded border-slate-300 accent-emerald-600 cursor-pointer"
                        />
                        <span className="flex items-start gap-2 text-sm text-slate-700">
                          <ShieldCheck className="h-5 w-5 flex-shrink-0 text-emerald-600" />
                          I confirm I have reviewed this application in full, including the licence photos and police check document.
                        </span>
                      </label>
                    </div>
                  ) : (
                    <div className="flex gap-3 pt-4 border-t border-slate-200">
                      <button
                        onClick={() => handleAction(selectedDriver._id, "approve")}
                        disabled={actionLoading}
                        className="flex-1 flex items-center justify-center gap-2 rounded-xl bg-green-600 py-3 text-sm font-semibold text-white transition hover:bg-green-700 disabled:opacity-50"
                      >
                        <CheckCircle className="h-4 w-4" />
                        Approve Application
                      </button>
                      <button
                        onClick={() => openRejectModal(selectedDriver._id)}
                        disabled={actionLoading}
                        className="flex-1 flex items-center justify-center gap-2 rounded-xl bg-red-600 py-3 text-sm font-semibold text-white transition hover:bg-red-700 disabled:opacity-50"
                      >
                        <XCircle className="h-4 w-4" />
                        Reject Application
                      </button>
                    </div>
                  )
                )}

                {selectedDriver.status === "approved" && (
                  <div className="pt-4 border-t border-slate-200">
                    <button
                      onClick={() => handleAction(selectedDriver._id, "suspend")}
                      disabled={actionLoading}
                      className="w-full flex items-center justify-center gap-2 rounded-xl border border-slate-200 py-3 text-sm font-semibold text-slate-700 transition hover:bg-slate-50 disabled:opacity-50"
                    >
                      <Ban className="h-4 w-4" />
                      Suspend Driver
                    </button>
                  </div>
                )}

                {selectedDriver.status === "suspended" && (
                  <div className="pt-4 border-t border-slate-200">
                    <button
                      onClick={() => handleAction(selectedDriver._id, "reactivate")}
                      disabled={actionLoading}
                      className="w-full flex items-center justify-center gap-2 rounded-xl bg-green-600 py-3 text-sm font-semibold text-white transition hover:bg-green-700 disabled:opacity-50"
                    >
                      <CheckCircle className="h-4 w-4" />
                      Reactivate Driver
                    </button>
                  </div>
                )}

                {/* Rejection History */}
                {selectedDriver.rejectionHistory && selectedDriver.rejectionHistory.length > 0 && (
                  <div className="rounded-xl border border-slate-200 p-4">
                    <div className="flex items-center gap-2 text-sm font-semibold text-slate-800 mb-3">
                      <History className="h-4 w-4 text-red-600" />
                      Rejection History
                    </div>
                    <div className="space-y-3">
                      {selectedDriver.rejectionHistory.map((rejection, index) => (
                        <div key={index} className="bg-red-50 rounded-lg p-3 text-sm border border-red-100">
                          <div className="flex justify-between items-start">
                            <span className="text-red-800 font-medium">
                              Rejected {formatDate(rejection.rejectedAt)}
                            </span>
                          </div>
                          <p className="text-red-700 mt-1">{rejection.reason}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Delete Option for Rejected Applications */}
                {selectedDriver.status === "rejected" && (
                  <div className="pt-4 border-t border-red-200 bg-red-50 -mx-6 -mb-6 p-6 rounded-b-3xl mt-4">
                    <div className="flex items-start gap-3">
                      <AlertTriangle className="h-5 w-5 text-red-600 flex-shrink-0 mt-0.5" />
                      <div className="flex-1">
                        <h4 className="text-sm font-semibold text-red-900">Permanent Deletion</h4>
                        <p className="text-xs text-red-700 mt-1">
                          This application was rejected
                          {selectedDriver.reviewedAt && ` on ${formatDate(selectedDriver.reviewedAt)}`}.
                          {selectedDriver.rejectionReason && (
                            <span className="block mt-1">Reason: {selectedDriver.rejectionReason}</span>
                          )}
                        </p>
                        <button
                          onClick={() => openDeleteModal(selectedDriver._id)}
                          className="mt-3 flex items-center gap-2 rounded-lg bg-red-600 px-4 py-2 text-sm font-semibold text-white transition hover:bg-red-700"
                        >
                          <Trash2 className="h-4 w-4" />
                          Delete Application
                        </button>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Rejection Reason Modal */}
        {showRejectModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
            <div className="w-full max-w-md rounded-2xl bg-white p-6 shadow-2xl">
              <h3 className="text-lg font-semibold text-slate-900 mb-2">Reject Application</h3>
              <p className="text-sm text-slate-600 mb-4">
                Please provide a reason for rejecting this application. This will be visible to the applicant.
              </p>
              <textarea
                value={rejectionReason}
                onChange={(e) => setRejectionReason(e.target.value)}
                placeholder="Enter rejection reason..."
                rows={4}
                className="w-full rounded-xl border border-slate-200 p-3 text-sm text-slate-900 placeholder:text-slate-400 focus:border-red-500 focus:outline-none focus:ring-2 focus:ring-red-500/20"
              />
              <div className="flex gap-3 mt-4">
                <button
                  onClick={() => {
                    setShowRejectModal(false);
                    setRejectionReason("");
                    setDriverToReject(null);
                  }}
                  className="flex-1 rounded-xl border border-slate-200 py-3 text-sm font-semibold text-slate-700 transition hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  onClick={() => driverToReject && handleAction(driverToReject, "reject", rejectionReason)}
                  disabled={actionLoading || !rejectionReason.trim()}
                  className="flex-1 rounded-xl bg-red-600 py-3 text-sm font-semibold text-white transition hover:bg-red-700 disabled:opacity-50"
                >
                  {actionLoading ? "Rejecting..." : "Confirm Rejection"}
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Delete Confirmation Modal */}
        {showDeleteModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
            <div className="w-full max-w-md rounded-2xl bg-white p-6 shadow-2xl">
              <div className="flex items-center gap-3 mb-4">
                <div className="flex h-12 w-12 items-center justify-center rounded-full bg-red-100">
                  <AlertTriangle className="h-6 w-6 text-red-600" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-slate-900">Delete Application</h3>
                  <p className="text-sm text-slate-500">This action cannot be undone</p>
                </div>
              </div>

              <div className="bg-red-50 border border-red-200 rounded-xl p-4 mb-4">
                <p className="text-sm text-red-800">
                  This will permanently delete the driver application and all associated data.
                  The user account will be converted back to a regular customer account.
                </p>
              </div>

              <div className="mb-4">
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Type <span className="font-mono bg-slate-100 px-1 rounded">DELETE</span> to confirm:
                </label>
                <input
                  type="text"
                  value={deleteConfirmText}
                  onChange={(e) => setDeleteConfirmText(e.target.value)}
                  placeholder="DELETE"
                  className="w-full rounded-xl border border-slate-200 p-3 text-sm text-slate-900 placeholder:text-slate-400 focus:border-red-500 focus:outline-none focus:ring-2 focus:ring-red-500/20"
                />
              </div>

              <div className="flex gap-3">
                <button
                  onClick={() => {
                    setShowDeleteModal(false);
                    setDriverToDelete(null);
                    setDeleteConfirmText("");
                  }}
                  className="flex-1 rounded-xl border border-slate-200 py-3 text-sm font-semibold text-slate-700 transition hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  onClick={() => driverToDelete && handleDelete(driverToDelete)}
                  disabled={actionLoading || deleteConfirmText !== "DELETE"}
                  className="flex-1 rounded-xl bg-red-600 py-3 text-sm font-semibold text-white transition hover:bg-red-700 disabled:opacity-50"
                >
                  {actionLoading ? "Deleting..." : "Permanently Delete"}
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// A licence photo thumbnail that opens the full Blob URL in a new tab.
// Falls back to a placeholder when the URL is missing (e.g. one side only).
function LicenceThumb({ label, url }: { label: string; url?: string }) {
  if (!url) {
    return (
      <div className="flex aspect-video w-full flex-col items-center justify-center gap-1 rounded-xl border border-dashed border-slate-200 bg-slate-50 text-center">
        <ImageIcon className="h-5 w-5 text-slate-300" />
        <span className="text-[11px] text-slate-400">{label}</span>
        <span className="text-[10px] text-slate-300">Not provided</span>
      </div>
    );
  }
  return (
    <a href={url} target="_blank" rel="noopener noreferrer" className="group block" title={`Open ${label} in a new tab`}>
      <div className="relative aspect-video w-full overflow-hidden rounded-xl border border-slate-200">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src={url} alt={label} className="h-full w-full object-cover transition group-hover:opacity-90" />
        <span className="absolute bottom-1 right-1 inline-flex items-center gap-1 rounded-md bg-black/60 px-1.5 py-0.5 text-[10px] font-medium text-white">
          <ExternalLink className="h-2.5 w-2.5" /> Open
        </span>
      </div>
      <p className="mt-1 text-[11px] font-medium text-slate-600">{label}</p>
    </a>
  );
}
